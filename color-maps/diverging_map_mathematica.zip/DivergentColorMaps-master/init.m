(* ::Package:: *)

Get["DivergentColorMaps`DivergentColorMaps`"];
